#include "Engine.h"

void main() { (new Engine())->Run(); }